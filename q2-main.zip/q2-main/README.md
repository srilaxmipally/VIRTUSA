## Run

```sh
git clone https://github.com/ImAvinashSharma/q2
cd q2
npm install
npm run start
```